package cn.ml.item.service.impl;

import cn.ml.item.pojo.Item;
import cn.ml.item.service.ItemService;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Collection;
import java.util.Hashtable;


@Service
public class ItemServiceImpl implements ItemService {
    private Object ename;
    private Object ud;

    private Hashtable<String, Item> items=new Hashtable<>();
    private long max=7L;

    public ItemServiceImpl(){
        Workbook workbook=null;
        try {
            workbook = new XSSFWorkbook("商品数据.xlsx");
        } catch (IOException e){
            throw new RuntimeException(e);
        }
        Sheet sheet=workbook.getSheetAt(0);
        int index=0;
        Row row=null;
        while((row=sheet.getRow(index))!=null){
            Cell idCell=row.getCell(0);
            idCell.setCellType(CellType.STRING);
            Cell nameCell=row.getCell(1);
            Cell modelCell=row.getCell(2);
            Cell brandCell=row.getCell(3);
            Cell stockCell=row.getCell(4);
            Cell priceCell=row.getCell(5);
            Cell catCell=row.getCell(6);
            Cell picCell=row.getCell(7);
            int id=(int)idCell.getNumericCellValue();
            String name=nameCell.getStringCellValue();
            String model=modelCell.getStringCellValue();
            String brand=brandCell.getStringCellValue();
            int stock=(int)stockCell.getNumericCellValue();
            double price=priceCell.getNumericCellValue();
            String cat=catCell.getStringCellValue();
            String pic=picCell.getStringCellValue();

            Item item = new Item(id, name, model, brand, stock, price, cat, pic);
            items.put(String.valueOf(id),item);
            index++;
        }
    }

    @Override
    public Collection<Item> findAllItems() {
        return items.values();
    }

    @Override
    public Item findItemBydId(String id) {
        return null;
    }

    @Override
    public Item findItemId(String id) {
        return null;
    }

    @Override
    public Item findItemById(String id) {return items.get(id);}

    @Override
    public Item addItem(Item item) {
        max++;
        item.setId(Integer.parseInt(max+""));
        items.put("XXX",item);
        return item;
    }

    @Override
    public Item update(String id, Item item) {
        items.put(id,item);
        return item;
    }

    @Override
    public int delete(String id) {
        Item item=items.remove(id);
        if(item!=null) return 1;
        else return 0;
    }

    public static void main(String[] args) throws Exception{
        Workbook workbook=new XSSFWorkbook("商品数据.xlsx");
        Sheet sheet=workbook.getSheetAt(0);
        int index=0;
        Row row=null;
        while ((row=sheet.getRow(index))!=null){
            Cell cell=row.getCell(1);
            String value =cell.getStringCellValue();
            System.out.println(value);
            index++;
        }
    }
}
