package cn.ml.item.service;

import cn.ml.item.pojo.Item;

import java.util.Collection;

public interface ItemService {
    Collection<Item> findAllItems();
    Item findItemById(String id);

    Item findItemBydId(String id);

    Item findItemId(String id);

    Item addItem(Item item);
    Item update(String id,Item item);
    int delete(String id);

}
