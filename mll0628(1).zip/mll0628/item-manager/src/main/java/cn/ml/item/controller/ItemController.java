package cn.ml.item.controller;

import cn.ml.commons.pojo.Goods;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class ItemController {

    @Autowired
    private RestTemplate restTemplate;

    @GetMapping(value = "/selectItem{cid}")
    public Goods selectItem(@PathVariable int cid){
        String url="http://localhost:8090/goods/"+cid;
        Goods goods=restTemplate.getForObject("",Goods.class);
        return goods;
    }
}
