package cn.ml.goods.controller;


import cn.ml.commons.pojo.Goods;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GoodsController {
    @GetMapping(value = "/goods/{id}")
    public Goods findGoodsById(@PathVariable int id){
        Goods goods=new Goods(id,"薯片");

        return goods;
    }
}
